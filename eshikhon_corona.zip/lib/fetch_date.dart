import 'dart:convert';
import 'dart:io';

import 'package:eshikhon_corona/model.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class FetchData extends GetxController {
  List<Patient> jsonData = [];
  String? error;

  Future<void> getData() async {
    jsonData = [];
    error = null;
    update();
    try {
      List<dynamic> jsonMetaData = await http.get(Uri.parse("https://api.covidtracking.com/v1/states/current.json")).then((value) {
        return jsonDecode(value.body);
      });
      for (var element in jsonMetaData) {
        jsonData.add(Patient.fromJson(element));
      }
    } on TypeError {
      error = "Server not found or taking so much time to reach.";
    } on SocketException {
      error = "No internet connection.";
    } catch (e) {
      error = e.toString();
    }
    update();
  }

  FetchData() {
    getData();
  }
}
