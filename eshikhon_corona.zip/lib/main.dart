import 'dart:ui';

import 'package:eshikhon_corona/fetch_date.dart';
import 'package:eshikhon_corona/model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fl_chart/fl_chart.dart';

void main(List<String> args) {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      scrollBehavior: const MaterialScrollBehavior().copyWith(dragDevices: {
        PointerDeviceKind.mouse,
        PointerDeviceKind.touch,
      }),
      debugShowCheckedModeBanner: false,
      home: const MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Covid-19"),
        centerTitle: true,
      ),
      body: GetBuilder<FetchData>(
        init: FetchData(),
        builder: (value) {
          if (value.jsonData.isEmpty) {
            if (value.error == null) {
              return const Center(child: CircularProgressIndicator());
            } else {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      value.error!,
                      textAlign: TextAlign.center,
                      softWrap: true,
                    ),
                    const SizedBox(height: 25),
                    IconButton(
                      icon: const Icon(Icons.replay_outlined),
                      onPressed: () {
                        value.getData();
                      },
                    ),
                  ],
                ),
              );
            }
          }

          return Column(
            children: [
              Expanded(
                child: MainWidget(
                  onRefresh: value.getData,
                  jsonData: value.jsonData,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Text("Update on ${dateToString(value.jsonData[0].date)}"),
              ),
            ],
          );
        },
      ),
    );
  }
}

class MainWidget extends StatefulWidget {
  final Future<void> Function() onRefresh;
  final List<Patient> jsonData;

  const MainWidget({required this.onRefresh, required this.jsonData, Key? key}) : super(key: key);

  @override
  State<MainWidget> createState() => _MainWidgetState();
}

class _MainWidgetState extends State<MainWidget> {
  List<PieChartSectionData> pieDataRP = [];
  List<PieChartSectionData> pieDataDR = [];
  double totalTestResults = 0;
  double positive = 0;
  double recovered = 0;
  double death = 0;
  double hospitalized = 0;

  void totalCount() async {
    for (var element in widget.jsonData) {
      totalTestResults = totalTestResults + element.totalTestResults;
      positive = positive + element.positive;
      recovered = recovered + element.recovered;
      death = death + element.death;
      hospitalized = hospitalized + element.hospitalized;
    }

    setState(() {
      pieDataRP = [
        PieChartSectionData(title: "Total Test", value: totalTestResults),
        PieChartSectionData(title: "Positive", value: positive, color: Colors.red),
        PieChartSectionData(title: "Recovered", value: recovered, color: Colors.grey),
        PieChartSectionData(title: "Death", value: death, color: Colors.black),
        PieChartSectionData(title: "Hospitalized", value: death, color: Colors.amber),
      ];
      pieDataDR = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    totalCount();
    return RefreshIndicator(
        onRefresh: widget.onRefresh,
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Container(
            constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height),
            child: ListView.builder(
              itemCount: widget.jsonData.length + 1,
              itemBuilder: ((context, index) {
                if (index == 0) {
                  return Column(
                    children: [
                      TotalCount(pieData: pieDataRP),
                    ],
                  );
                } else {
                  return GestureDetector(
                    onTap: () {
                      print(widget.jsonData[index - 1].toString());
                      Get.to(Detail(
                        data: widget.jsonData[index - 1],
                      ));
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: const Color.fromARGB(25, 33, 149, 243),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                            // height: 10,
                            width: 80,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              image: fetchImage("lib/assets/images/flags/${widget.jsonData[index - 1].state}.png"),
                              borderRadius: BorderRadius.circular(10),
                              color: const Color.fromARGB(50, 33, 149, 243),
                            ),
                            child: Text(
                              widget.jsonData[index - 1].state,
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                  "Total Test: ${widget.jsonData[index - 1].totalTestResults == 0 ? "Not found" : widget.jsonData[index - 1].totalTestResults}"),
                              const SizedBox(width: 20),
                              Text("Positive: ${widget.jsonData[index - 1].positive == 0 ? "Not found" : widget.jsonData[index - 1].positive}"),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Recovered: ${widget.jsonData[index - 1].recovered == 0 ? "Not found" : widget.jsonData[index - 1].recovered}"),
                              const SizedBox(width: 20),
                              Text("Death: ${widget.jsonData[index - 1].death == 0 ? "Not found" : widget.jsonData[index - 1].death}"),
                            ],
                          ),
                          Text(
                              "Hospitalized: ${widget.jsonData[index - 1].hospitalized == 0 ? "Not found" : widget.jsonData[index - 1].hospitalized}"),
                        ],
                      ),
                    ),
                  );
                }
              }),
            ),
          ),
        ));
  }
}

class TotalCount extends StatelessWidget {
  const TotalCount({
    Key? key,
    required this.pieData,
  }) : super(key: key);

  final List<PieChartSectionData> pieData;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      // height: MediaQuery.of(context).size.width / 2,
      // width: MediaQuery.of(context).size.width,
      // constraints: const BoxConstraints(maxHeight: 400),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: const Color.fromARGB(25, 33, 149, 243),
      ),
      child: Column(
        children: [
          Container(
            height: MediaQuery.of(context).size.width / 2,
            // width: MediaQuery.of(context).size.width,
            constraints: const BoxConstraints(maxHeight: 400),
            child: PieChart(
              PieChartData(
                borderData: FlBorderData(show: false),
                sectionsSpace: 0,
                startDegreeOffset: 90,
                centerSpaceRadius: MediaQuery.of(context).size.width / 9,
                sections: pieData.map((e) => e.copyWith(title: "")).toList(),
              ),
            ),
          ),
          Column(
            children: pieData
                .map((e) => Row(
                      // mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(width: 10),
                        Container(width: 10, height: 10, color: e.color),
                        const SizedBox(width: 10),
                        Text(
                          "${e.title} ${e.value.toInt()}",
                          style: const TextStyle(
                            // color: e.color,
                            color: Colors.grey,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ))
                .toList(),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}

String dateToString(int fulldate) {
  return "${fulldate.toString().substring(0, 4)} / ${fulldate.toString().substring(4, 6)} / ${fulldate.toString().substring(6)}";
}

DecorationImage fetchImage(String location) {
  return DecorationImage(
    image: imageValid(location),
    fit: BoxFit.cover,
    opacity: 0.5,
    onError: (exception, stackTrace) {},
  );
}

AssetImage imageValid(String location) {
  AssetImage image;
  try {
    image = AssetImage(location);
  } catch (_) {
    print("sssssss");
    image = const AssetImage("lib/assets/images/error_loading.png");
  }
  return image;
}

class Detail extends StatelessWidget {
  final Patient data;
  const Detail({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("${data.state} (${dateToString(data.date)})"), centerTitle: true),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                alignment: Alignment.center,
                child: Image.asset(
                  "lib/assets/images/flags/${data.state}.png",
                  errorBuilder: (context, error, stackTrace) => Image.asset("lib/assets/images/error_loading.png"),
                ),
              ),
              const SizedBox(height: 20),
              Text("Total Test Results: ${data.totalTestResults == 0 ? "Not found" : data.totalTestResults}"),
              Text("Positive: ${data.positive == 0 ? "Not found" : data.positive}"),
              Text("Death: ${data.death == 0 ? "Not found" : data.death}"),
              Text("Hospitalized: ${data.hospitalized == 0 ? "Not found" : data.hospitalized}"),
              Text("HospitalizedDischarged: ${data.hospitalizedDischarged == 0 ? "Not found" : data.hospitalizedDischarged}"),
              Text("Total Tests Viral: ${data.totalTestsViral == 0 ? "Not found" : data.totalTestsViral}"),
              Text("Positive Tests Viral: ${data.positiveTestsViral == 0 ? "Not found" : data.positiveTestsViral}"),
              Text("Negative Tests Viral: ${data.negativeTestsViral == 0 ? "Not found" : data.negativeTestsViral}"),
              Text("Positive Cases Viral: ${data.positiveCasesViral == 0 ? "Not found" : data.positiveCasesViral}"),
              Text("Death Confirmed: ${data.deathConfirmed == 0 ? "Not found" : data.deathConfirmed}"),
              Text("Total Test Encounters Viral: ${data.totalTestEncountersViral == 0 ? "Not found" : data.totalTestEncountersViral}"),
              Text("Total Tests People Viral: ${data.totalTestsPeopleViral == 0 ? "Not found" : data.totalTestsPeopleViral}"),
              Text("Total Tests Antibody: ${data.totalTestsAntibody == 0 ? "Not found" : data.totalTestsAntibody}"),
              Text("Positive Tests Antibody: ${data.positiveTestsAntibody == 0 ? "Not found" : data.positiveTestsAntibody}"),
              Text("Negative Tests Antibody: ${data.negativeTestsAntibody == 0 ? "Not found" : data.negativeTestsAntibody}"),
              Text("Total Tests People Antibody: ${data.totalTestsPeopleAntibody == 0 ? "Not found" : data.totalTestsPeopleAntibody}"),
              Text("Positive Tests People Antibody: ${data.positiveTestsPeopleAntibody == 0 ? "Not found" : data.positiveTestsPeopleAntibody}"),
              Text("Negative Tests People Antibody: ${data.negativeTestsPeopleAntibody == 0 ? "Not found" : data.negativeTestsPeopleAntibody}"),
              Text("Total Tests People Antigen: ${data.totalTestsPeopleAntigen == 0 ? "Not found" : data.totalTestsPeopleAntigen}"),
              Text("Positive Tests People Antigen: ${data.positiveTestsPeopleAntigen == 0 ? "Not found" : data.positiveTestsPeopleAntigen}"),
              Text("Total Tests Antigen: ${data.totalTestsAntigen == 0 ? "Not found" : data.totalTestsAntigen}"),
              Text("Positive Tests Antigen: ${data.positiveTestsAntigen == 0 ? "Not found" : data.positiveTestsAntigen}"),
              Text("PositiveIncrease: ${data.positiveIncrease}"),
              Text("NegativeIncrease: ${data.negativeIncrease}"),
              Text("Total: ${data.total == 0 ? "Not found" : data.total}"),
              Text("Total Test Results Increase: ${data.totalTestResultsIncrease}"),
            ],
          ),
        ),
      ),
    );
  }
}
