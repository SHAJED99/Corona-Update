import 'package:charts_flutter/flutter.dart';

class Patient {
  late int date;
  late String state;
  late int positive;
  late int probableCases;
  late int negative;
  late int pending;
  late String totalTestResultsSource;
  late int totalTestResults;
  late int hospitalizedCurrently;
  late int hospitalizedCumulative;
  late int inIcuCurrently;
  late int inIcuCumulative;
  late int onVentilatorCurrently;
  late int onVentilatorCumulative;
  late int recovered;
  late String lastUpdateEt;
  late String dateModified;
  late String checkTimeEt;
  late int death;
  late int hospitalized;
  late int hospitalizedDischarged;
  late String dateChecked;
  late int totalTestsViral;
  late int positiveTestsViral;
  late int negativeTestsViral;
  late int positiveCasesViral;
  late int deathConfirmed;
  late int deathProbable;
  late int totalTestEncountersViral;
  late int totalTestsPeopleViral;
  late int totalTestsAntibody;
  late int positiveTestsAntibody;
  late int negativeTestsAntibody;
  late int totalTestsPeopleAntibody;
  late int positiveTestsPeopleAntibody;
  late int negativeTestsPeopleAntibody;
  late int totalTestsPeopleAntigen;
  late int positiveTestsPeopleAntigen;
  late int totalTestsAntigen;
  late int positiveTestsAntigen;
  late String fips;
  late int positiveIncrease;
  late int negativeIncrease;
  late int total;
  late int totalTestResultsIncrease;
  late int posNeg;
  late int deathIncrease;
  late int hospitalizedIncrease;
  late String hash;
  late int commercialScore;
  late int negativeRegularScore;
  late int negativeScore;
  late int positiveScore;
  late int score;
  late String grade;

  Patient({
    this.date = 0,
    this.state = "",
    this.positive = 0,
    this.probableCases = 0,
    this.negative = 0,
    this.pending = 0,
    this.totalTestResultsSource = "",
    this.totalTestResults = 0,
    this.hospitalizedCurrently = 0,
    this.hospitalizedCumulative = 0,
    this.inIcuCurrently = 0,
    this.inIcuCumulative = 0,
    this.onVentilatorCurrently = 0,
    this.onVentilatorCumulative = 0,
    this.recovered = 0,
    this.lastUpdateEt = "",
    this.dateModified = "",
    this.checkTimeEt = "",
    this.death = 0,
    this.hospitalized = 0,
    this.hospitalizedDischarged = 0,
    this.dateChecked = "",
    this.totalTestsViral = 0,
    this.positiveTestsViral = 0,
    this.negativeTestsViral = 0,
    this.positiveCasesViral = 0,
    this.deathConfirmed = 0,
    this.deathProbable = 0,
    this.totalTestEncountersViral = 0,
    this.totalTestsPeopleViral = 0,
    this.totalTestsAntibody = 0,
    this.positiveTestsAntibody = 0,
    this.negativeTestsAntibody = 0,
    this.totalTestsPeopleAntibody = 0,
    this.positiveTestsPeopleAntibody = 0,
    this.negativeTestsPeopleAntibody = 0,
    this.totalTestsPeopleAntigen = 0,
    this.positiveTestsPeopleAntigen = 0,
    this.totalTestsAntigen = 0,
    this.positiveTestsAntigen = 0,
    this.fips = "",
    this.positiveIncrease = 0,
    this.negativeIncrease = 0,
    this.total = 0,
    this.totalTestResultsIncrease = 0,
    this.posNeg = 0,
    this.deathIncrease = 0,
    this.hospitalizedIncrease = 0,
    this.hash = "",
    this.commercialScore = 0,
    this.negativeRegularScore = 0,
    this.negativeScore = 0,
    this.positiveScore = 0,
    this.score = 0,
    this.grade = "",
  });

  Patient.fromJson(Map<String, dynamic> json) {
    date = json['date'] ?? 0;
    state = json['state'] ?? "";
    positive = json['positive'] ?? 0;
    probableCases = json['probableCases'] ?? 0;
    negative = json['negative'] ?? 0;
    pending = json['pending'] ?? 0;
    totalTestResultsSource = json['totalTestResultsSource'] ?? "";
    totalTestResults = json['totalTestResults'] ?? 0;
    hospitalizedCurrently = json['hospitalizedCurrently'] ?? 0;
    hospitalizedCumulative = json['hospitalizedCumulative'] ?? 0;
    inIcuCurrently = json['inIcuCurrently'] ?? 0;
    inIcuCumulative = json['inIcuCumulative'] ?? 0;
    onVentilatorCurrently = json['onVentilatorCurrently'] ?? 0;
    onVentilatorCumulative = json['onVentilatorCumulative'] ?? 0;
    recovered = json['recovered'] ?? 0;
    lastUpdateEt = json['lastUpdateEt'] ?? "";
    dateModified = json['dateModified'] ?? "";
    checkTimeEt = json['checkTimeEt'] ?? "";
    death = json['death'] ?? 0;
    hospitalized = json['hospitalized'] ?? 0;
    hospitalizedDischarged = json['hospitalizedDischarged'] ?? 0;
    dateChecked = json['dateChecked'] ?? 0;
    totalTestsViral = json['totalTestsViral'] ?? 0;
    positiveTestsViral = json['positiveTestsViral'] ?? 0;
    negativeTestsViral = json['negativeTestsViral'] ?? 0;
    positiveCasesViral = json['positiveCasesViral'] ?? 0;
    deathConfirmed = json['deathConfirmed'] ?? 0;
    deathProbable = json['deathProbable'] ?? 0;
    totalTestEncountersViral = json['totalTestEncountersViral'] ?? 0;
    totalTestsPeopleViral = json['totalTestsPeopleViral'] ?? 0;
    totalTestsAntibody = json['totalTestsAntibody'] ?? 0;
    positiveTestsAntibody = json['positiveTestsAntibody'] ?? 0;
    negativeTestsAntibody = json['negativeTestsAntibody'] ?? 0;
    totalTestsPeopleAntibody = json['totalTestsPeopleAntibody'] ?? 0;
    positiveTestsPeopleAntibody = json['positiveTestsPeopleAntibody'] ?? 0;
    negativeTestsPeopleAntibody = json['negativeTestsPeopleAntibody'] ?? 0;
    totalTestsPeopleAntigen = json['totalTestsPeopleAntigen'] ?? 0;
    positiveTestsPeopleAntigen = json['positiveTestsPeopleAntigen'] ?? 0;
    totalTestsAntigen = json['totalTestsAntigen'] ?? 0;
    positiveTestsAntigen = json['positiveTestsAntigen'] ?? 0;
    fips = json['fips'] ?? "";
    positiveIncrease = json['positiveIncrease'] ?? 0;
    negativeIncrease = json['negativeIncrease'] ?? 0;
    total = json['total'] ?? 0;
    totalTestResultsIncrease = json['totalTestResultsIncrease'] ?? 0;
    posNeg = json['posNeg'] ?? 0;
    deathIncrease = json['deathIncrease'] ?? 0;
    hospitalizedIncrease = json['hospitalizedIncrease'] ?? 0;
    hash = json['hash'] ?? "";
    commercialScore = json['commercialScore'] ?? 0;
    negativeRegularScore = json['negativeRegularScore'] ?? 0;
    negativeScore = json['negativeScore'] ?? 0;
    positiveScore = json['positiveScore'] ?? 0;
    score = json['score'] ?? 0;
    grade = json['grade'] ?? "";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['date'] = date;
    data['state'] = state;
    data['positive'] = positive;
    data['probableCases'] = probableCases;
    data['negative'] = negative;
    data['pending'] = pending;
    data['totalTestResultsSource'] = totalTestResultsSource;
    data['totalTestResults'] = totalTestResults;
    data['hospitalizedCurrently'] = hospitalizedCurrently;
    data['hospitalizedCumulative'] = hospitalizedCumulative;
    data['inIcuCurrently'] = inIcuCurrently;
    data['inIcuCumulative'] = inIcuCumulative;
    data['onVentilatorCurrently'] = onVentilatorCurrently;
    data['onVentilatorCumulative'] = onVentilatorCumulative;
    data['recovered'] = recovered;
    data['lastUpdateEt'] = lastUpdateEt;
    data['dateModified'] = dateModified;
    data['checkTimeEt'] = checkTimeEt;
    data['death'] = death;
    data['hospitalized'] = hospitalized;
    data['hospitalizedDischarged'] = hospitalizedDischarged;
    data['dateChecked'] = dateChecked;
    data['totalTestsViral'] = totalTestsViral;
    data['positiveTestsViral'] = positiveTestsViral;
    data['negativeTestsViral'] = negativeTestsViral;
    data['positiveCasesViral'] = positiveCasesViral;
    data['deathConfirmed'] = deathConfirmed;
    data['deathProbable'] = deathProbable;
    data['totalTestEncountersViral'] = totalTestEncountersViral;
    data['totalTestsPeopleViral'] = totalTestsPeopleViral;
    data['totalTestsAntibody'] = totalTestsAntibody;
    data['positiveTestsAntibody'] = positiveTestsAntibody;
    data['negativeTestsAntibody'] = negativeTestsAntibody;
    data['totalTestsPeopleAntibody'] = totalTestsPeopleAntibody;
    data['positiveTestsPeopleAntibody'] = positiveTestsPeopleAntibody;
    data['negativeTestsPeopleAntibody'] = negativeTestsPeopleAntibody;
    data['totalTestsPeopleAntigen'] = totalTestsPeopleAntigen;
    data['positiveTestsPeopleAntigen'] = positiveTestsPeopleAntigen;
    data['totalTestsAntigen'] = totalTestsAntigen;
    data['positiveTestsAntigen'] = positiveTestsAntigen;
    data['fips'] = fips;
    data['positiveIncrease'] = positiveIncrease;
    data['negativeIncrease'] = negativeIncrease;
    data['total'] = total;
    data['totalTestResultsIncrease'] = totalTestResultsIncrease;
    data['posNeg'] = posNeg;
    data['deathIncrease'] = deathIncrease;
    data['hospitalizedIncrease'] = hospitalizedIncrease;
    data['hash'] = hash;
    data['commercialScore'] = commercialScore;
    data['negativeRegularScore'] = negativeRegularScore;
    data['negativeScore'] = negativeScore;
    data['positiveScore'] = positiveScore;
    data['score'] = score;
    data['grade'] = grade;
    return data;
  }
}

class Data {
  final String label;
  final double percent;
  final Color color;

  Data({required this.label, required this.percent, required this.color});
}
